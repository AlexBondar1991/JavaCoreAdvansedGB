package ru.geekbrains.participants;

public class Cat extends Animal {

    public Cat(String name) {
        super("Кот", name, 200, 10, 2);
    }
}
