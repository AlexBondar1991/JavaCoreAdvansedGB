package ru.geekbrains.implementation;

public abstract class Obstacle {
    public abstract String doit(Competitor competitor);
}
